-- --------------------------------------------------------
-- Estructura de tabla para configuracion
-- --------------------------------------------------------

CREATE TABLE `configuracion` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `identidad` varchar(20) NOT NULL,
  `nombre` varchar(255) NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `correo` varchar(150) NOT NULL,
  `direccion` text NOT NULL,
  `mensaje` text DEFAULT NULL,
  `tasa_interes` int(11) NOT NULL,
  `cuotas` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `identidad` (`identidad`),
  UNIQUE KEY `telefono` (`telefono`),
  UNIQUE KEY `correo` (`correo`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------
-- Datos de tabla para configuracion
-- --------------------------------------------------------

INSERT INTO `configuracion` VALUES ('1', '123456789', 'VIDA INFORMÁTICO', '900897537', 'info@angelsifuentes.net', 'Perú', 'GRACIAS POR ADQUIRIR EL CURSO', '10', '18', '2024-07-10 14:17:21', '2024-07-10 14:17:21');

-- --------------------------------------------------------
-- Estructura de tabla para migrations
-- --------------------------------------------------------

CREATE TABLE `migrations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `group` varchar(255) NOT NULL,
  `namespace` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  `batch` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------
-- Datos de tabla para migrations
-- --------------------------------------------------------

INSERT INTO `migrations` VALUES ('1', '2023-06-26-145832', 'App\Database\Migrations\Admin', 'default', 'App', '1720637590', '1');
INSERT INTO `migrations` VALUES ('2', '2023-06-26-150959', 'App\Database\Migrations\Permisos', 'default', 'App', '1720637590', '1');
INSERT INTO `migrations` VALUES ('3', '2023-06-26-151017', 'App\Database\Migrations\Roles', 'default', 'App', '1720637590', '1');
INSERT INTO `migrations` VALUES ('4', '2023-06-26-151033', 'App\Database\Migrations\Usuarios', 'default', 'App', '1720637590', '1');
INSERT INTO `migrations` VALUES ('5', '2023-06-26-151046', 'App\Database\Migrations\Cajas', 'default', 'App', '1720637590', '1');
INSERT INTO `migrations` VALUES ('6', '2023-06-26-151051', 'App\Database\Migrations\Clientes', 'default', 'App', '1720637590', '1');
INSERT INTO `migrations` VALUES ('7', '2023-06-26-151104', 'App\Database\Migrations\Prestamos', 'default', 'App', '1720637590', '1');
INSERT INTO `migrations` VALUES ('8', '2023-06-26-151116', 'App\Database\Migrations\DetallePrestamos', 'default', 'App', '1720637590', '1');

-- --------------------------------------------------------
-- Estructura de tabla para permisos
-- --------------------------------------------------------

CREATE TABLE `permisos` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `modulo` varchar(150) NOT NULL,
  `campos` text NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------
-- Datos de tabla para permisos
-- --------------------------------------------------------

INSERT INTO `permisos` VALUES ('1', 'usuarios', '["listar usuarios","nuevo usuario","editar usuario","eliminar usuario"]', '2024-07-10 14:17:21', '2024-07-10 14:17:21');
INSERT INTO `permisos` VALUES ('2', 'configuracion', '["actualizar empresa","backup"]', '2024-07-10 14:17:21', '2024-07-10 14:17:21');
INSERT INTO `permisos` VALUES ('3', 'roles', '["listar roles","nuevo rol","editar rol","eliminar rol"]', '2024-07-10 14:17:21', '2024-07-10 14:17:21');
INSERT INTO `permisos` VALUES ('4', 'clientes', '["listar clientes","nuevo cliente","editar cliente","eliminar cliente"]', '2024-07-10 14:17:21', '2024-07-10 14:17:21');
INSERT INTO `permisos` VALUES ('5', 'prestamos', '["nuevo prestamo","historial prestamos","ver prestamo","eliminar prestamo","abono prestamo"]', '2024-07-10 14:17:21', '2024-07-10 14:17:21');
INSERT INTO `permisos` VALUES ('6', 'cajas', '["ver saldo"]', '2024-07-10 14:17:21', '2024-07-10 14:17:21');
INSERT INTO `permisos` VALUES ('7', 'reportes', '["pdf prestamos","excel prestamos"]', '2024-07-10 14:17:21', '2024-07-10 14:17:21');

-- --------------------------------------------------------
-- Estructura de tabla para roles
-- --------------------------------------------------------

CREATE TABLE `roles` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) NOT NULL,
  `permisos` text DEFAULT NULL,
  `estado` int(11) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------
-- Datos de tabla para roles
-- --------------------------------------------------------

INSERT INTO `roles` VALUES ('1', 'ADMINISTRADOR', '["listar usuarios","nuevo usuario","editar usuario","eliminar usuario","actualizar empresa","backup","listar roles","nuevo rol","editar rol","eliminar rol","listar clientes","nuevo cliente","editar cliente","eliminar cliente","nuevo prestamo","historial prestamos","ver prestamo","eliminar prestamo","abono prestamo","ver saldo","pdf prestamos","excel prestamos"]', '1', '2024-07-10 14:17:21', '2024-07-10 14:17:21');

-- --------------------------------------------------------
-- Estructura de tabla para usuarios
-- --------------------------------------------------------

CREATE TABLE `usuarios` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(150) NOT NULL,
  `apellido` varchar(150) NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `correo` varchar(150) NOT NULL,
  `direccion` text NOT NULL,
  `clave` varchar(200) NOT NULL,
  `perfil` varchar(20) DEFAULT NULL,
  `estado` int(11) NOT NULL DEFAULT 1,
  `token` varchar(100) DEFAULT NULL,
  `verify` int(11) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `id_rol` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `telefono` (`telefono`),
  UNIQUE KEY `correo` (`correo`),
  KEY `fk_roles` (`id_rol`),
  CONSTRAINT `fk_roles` FOREIGN KEY (`id_rol`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------
-- Datos de tabla para usuarios
-- --------------------------------------------------------

INSERT INTO `usuarios` VALUES ('1', 'ANGEL', 'SIFUENTES', '900897537', 'info@angelsifuentes.net', 'Perú', '$2y$10$y.vaIqO93C25hGqKCufQwOZXURws.qRVlxB55f2wTGvaAc953.TmK', '', '1', '', '1', '2024-07-10 14:17:21', '2024-07-10 14:17:21', '1');

